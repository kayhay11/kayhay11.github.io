package com.example.helloworld;

public class WeightEntry {
    private int id;
    private String date;
    private double currentWeight;
    private double goalWeight;
    private double pace;

    public WeightEntry(int id, String date, double currentWeight, double goalWeight, double pace) {
        this.id = id;
        this.date = date;
        this.currentWeight = currentWeight;
        this.goalWeight = goalWeight;
        this.pace = pace;
    }

    public int getId() { return id; }
    public String getDate() { return date; }
    public double getCurrentWeight() { return currentWeight; }
    public double getGoalWeight() { return goalWeight; }
    public double getPace() { return pace; }
}


