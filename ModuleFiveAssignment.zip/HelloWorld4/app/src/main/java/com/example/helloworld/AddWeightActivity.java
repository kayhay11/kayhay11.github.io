package com.example.helloworld;

import java.util.List;
import java.util.ArrayList;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class AddWeightActivity extends AppCompatActivity {

    EditText currentWeightInput, goalWeightInput, paceInput;
    FloatingActionButton fab;
    RecyclerView recyclerView;
    DBHelper dbHelper;

    double startingWeight = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_weight);

        currentWeightInput = findViewById(R.id.current_weight);
        goalWeightInput = findViewById(R.id.goal_weight);
        paceInput = findViewById(R.id.pace_toGoal);
        fab = findViewById(R.id.floatingActionButton);
        recyclerView = findViewById(R.id.recyclerView);


        dbHelper = new DBHelper(this);

        loadData();


        fab.setOnClickListener(v -> {
            String currentStr = currentWeightInput.getText().toString().trim();
            String goalStr = goalWeightInput.getText().toString().trim();

            if (currentStr.isEmpty() || goalStr.isEmpty()) {
                Toast.makeText(this, "Enter current and goal weight", Toast.LENGTH_SHORT).show();
                return;
            }

            double current = Double.parseDouble(currentStr);
            double goal = Double.parseDouble(goalStr);

            // If first time, set starting weight
            if (startingWeight == 0) {
                startingWeight = current;
            }

            // Calculate progress %
            double totalChangeNeeded = Math.abs(startingWeight - goal);
            double changeSoFar = Math.abs(startingWeight - current);

            double progress = (changeSoFar / totalChangeNeeded) * 100;

            if (progress < 0) progress = 0;
            if (progress > 100) progress = 100;

            paceInput.setText(String.format("%.1f%%", progress));


            // Save to DB
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("date", String.valueOf(System.currentTimeMillis()));
            values.put("current_weight", current);
            values.put("goal_weight", goal);
            values.put("pace", progress);

            long result = db.insert("my_weight", null, values);
            if (result != -1) {
                Toast.makeText(this, "Weight entry saved!", Toast.LENGTH_SHORT).show();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    private void loadData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM my_weight", null);

        List<WeightEntry> weightList = new ArrayList<>();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String date = cursor.getString(1);
            double current = cursor.getDouble(2);
            double goal = cursor.getDouble(3);
            double pace = cursor.getDouble(4);

            weightList.add(new WeightEntry(id, date, current, goal, pace));
        }
        cursor.close();

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(new WeightAdapter(weightList, dbHelper, startingWeight));

    }
    }