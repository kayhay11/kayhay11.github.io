package com.example.helloworld;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {
    private final List<WeightEntry> weightList;
    private final DBHelper dbHelper;
    private final double startingWeight;

    public WeightAdapter(List<WeightEntry> weightList, DBHelper dbHelper, double startingWeight) {
        this.weightList = weightList;
        this.dbHelper = dbHelper;
        this.startingWeight = startingWeight;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateText, currentText, goalText, paceText;
        Button updateButton, deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.dateText);
            currentText = itemView.findViewById(R.id.currentText);
            goalText = itemView.findViewById(R.id.goalText);
            paceText = itemView.findViewById(R.id.paceText);
            updateButton = itemView.findViewById(R.id.updateButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.weight_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        WeightEntry entry = weightList.get(position);

        holder.dateText.setText(entry.getDate());
        holder.currentText.setText("Current: " + entry.getCurrentWeight());
        holder.goalText.setText("Goal: " + entry.getGoalWeight());
        holder.paceText.setText("Progress: " + String.format("%.1f%%", entry.getPace()));

        // Delete action
        holder.deleteButton.setOnClickListener(v -> {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(v.getContext());
            builder.setTitle("Update Weight");

            final EditText input = new EditText(v.getContext());
            input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
            input.setHint("Enter new current weight");
            builder.setView(input);

            builder.setPositiveButton("Save", (dialog, which) -> {
                String newWeightStr = input.getText().toString().trim();
                if (!newWeightStr.isEmpty()) {
                    double newCurrent = Double.parseDouble(newWeightStr);

                    // Recalculate progress
                    double progress = ((startingWeight - newCurrent) / (startingWeight - entry.getGoalWeight())) * 100;
                    if (progress < 0) progress = 0;
                    if (progress > 100) progress = 100;

                    // Update DB
                    dbHelper.updateWeight(entry.getId(), newCurrent, entry.getGoalWeight(), progress);

                    // Update list + refresh row
                    weightList.set(position, new WeightEntry(entry.getId(), entry.getDate(), newCurrent, entry.getGoalWeight(), progress));
                    notifyItemChanged(position);
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();

        });
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }


}
