package com.example.helloworld;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightLog.db";
    private static final int DATABASE_VERSION = 2;

    public static final String USER_TABLE = "users";
    public static final String WEIGHT_TABLE = "my_weight";

    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + USER_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " +
                "password TEXT)");

        db.execSQL("CREATE TABLE " + WEIGHT_TABLE + " (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "date TEXT, " +
                "current_weight REAL, " +
                "goal_weight REAL, " +
                "pace REAL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + WEIGHT_TABLE);
        onCreate(db);
    }

    // User authentication
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long result = db.insert(USER_TABLE, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE +
                " WHERE username=? AND password=?", new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // CRUD for weights
    public long insertWeight(double current, double goal, double pace) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", String.valueOf(System.currentTimeMillis()));
        values.put("current_weight", current);
        values.put("goal_weight", goal);
        values.put("pace", pace);
        return db.insert(WEIGHT_TABLE, null, values);
    }

    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + WEIGHT_TABLE, null);
    }

    public Cursor getLatestWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM " + WEIGHT_TABLE + " ORDER BY date DESC LIMIT 1",
                null
        );
    }

    public void updateWeight(int id, double current, double goal, double pace) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("current_weight", current);
        values.put("goal_weight", goal);
        values.put("pace", pace);
        db.update(WEIGHT_TABLE, values, "_id=?", new String[]{String.valueOf(id)});
    }

    public int deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(WEIGHT_TABLE, "_id=?", new String[]{String.valueOf(id)});
    }




}
